from flask import Flask, render_template, request, jsonify
import math, time, json, os
from datetime import datetime

app = Flask(__name__)

# ── Ballari city centre coordinates ──
BALLARI_CENTER = {"lat": 15.1394, "lng": 76.9214}
BALLARI_RADIUS_KM = 80  # expanded to cover full Ballari + Vijayanagara district

# Robot speed in km/h
ROBOT_SPEED_KMH = 20

# Robot depot location (starting point) — near Ballari city centre
ROBOT_DEPOT = {"lat": 15.1420, "lng": 76.9180}

# Known Ballari area landmarks for reference
BALLARI_LANDMARKS = {
    "BITM": {"lat": 15.1677, "lng": 76.9125, "name": "BITM College, Ballari"},
    "centre": {"lat": 15.1394, "lng": 76.9214, "name": "Ballari City Centre"},
    "hospet": {"lat": 15.2689, "lng": 76.3870, "name": "Hospet"},
    "sandur": {"lat": 15.0804, "lng": 76.5520, "name": "Sandur"},
}

# Simple in-memory storage (replace with SQLite for persistence)
requests_db = []

PLASTIC_TYPES = {
    "PET":  {"full": "Polyethylene Terephthalate (PET/PETE)", "value_per_kg": 12, "uses": "Bottles, food containers"},
    "HDPE": {"full": "High-Density Polyethylene (HDPE)",       "value_per_kg": 15, "uses": "Milk jugs, detergent bottles"},
    "PVC":  {"full": "Polyvinyl Chloride (PVC)",               "value_per_kg": 8,  "uses": "Pipes, window frames"},
    "LDPE": {"full": "Low-Density Polyethylene (LDPE)",        "value_per_kg": 10, "uses": "Plastic bags, squeezable bottles"},
    "PP":   {"full": "Polypropylene (PP)",                     "value_per_kg": 11, "uses": "Yogurt containers, bottle caps"},
    "PS":   {"full": "Polystyrene (PS)",                       "value_per_kg": 6,  "uses": "Foam cups, packaging"},
}

CHATBOT_KB = {
    "plastic_types": [
        "EcoRoboVahan accepts 6 types of plastic: PET (bottles), HDPE (jugs), PVC (pipes), LDPE (bags), PP (caps), and PS (foam). Each is crushed into powder and sold to recyclers.",
        "We identify plastic using near-infrared spectroscopy sensors. PET plastic fetches ₹12/kg, HDPE ₹15/kg, PP ₹11/kg, and LDPE ₹10/kg in the current recycling market.",
        "The most common plastic we collect is PET — the clear bottles used for water and soft drinks. Drop them in, and our crusher reduces them to 10% of their original volume instantly."
    ],
    "revenue": [
        "You earn EcoCredits based on weight: approximately ₹8–15 per kg depending on plastic type. HDPE (milk jugs) fetches the highest rate at ₹15/kg.",
        "Our revenue model: crushed plastic powder is sold to industrial recyclers. We share 40% of that with users as EcoCredits, redeemable at partner stores.",
        "A typical 500ml PET bottle weighs ~20g. Collect 50 bottles (1kg) and earn ₹12 in EcoCredits. Monthly, an active household can save ₹200–500 this way."
    ],
    "working": [
        "EcoRoboVahan uses SLAM-based autonomous navigation (LIDAR + GPS). When you request pickup, the nearest robot routes to you using real-time pathfinding. It avoids obstacles and adapts to traffic.",
        "The detection system uses multi-spectral NIR sensors to classify material. Non-plastic items trigger an ejection arm. Accepted plastic goes into a 500W crushing chamber, reducing volume by 90%.",
        "Inside the robot's trolley: a belt conveyor feeds items to the sensor bay → material classified → accepted items enter the crusher → powder stored in sealed 20kg compartments → full compartments trigger auto-return to depot."
    ],
    "eta": [
        "ETA is calculated live: distance between your GPS coordinates and the robot's current position, divided by our robot's speed of 20 km/h. Updates every 10 seconds.",
        "Our robots maintain ~18-22 km/h on clear roads, adjusting for traffic density. The ETA shown on your map is accurate to ±30 seconds.",
    ],
    "power": [
        "EcoRoboVahan runs on a high-capacity rechargeable lithium power bank system — 72V, 50Ah. A full charge covers 80km of operation. Robots return to depot for recharging when battery drops below 15%.",
        "The power bank system uses fast-charging technology (0→80% in 45 minutes). We operate a fleet rotation to ensure 24/7 availability in Ballari."
    ],
    "ballari": [
        "We currently serve the entire Ballari district in Karnataka — covering Ballari city, Hospet, Sandur, and surrounding areas within a 30km radius.",
        "Ballari was chosen as our pilot city due to its industrial plastic waste density. We aim to expand to 5 more Karnataka cities by Q3 2026."
    ]
}

def haversine(lat1, lon1, lat2, lon2):
    """Calculate distance between two GPS points in km."""
    R = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    return R * 2 * math.asin(math.sqrt(a))

def is_in_ballari(lat, lng):
    dist = haversine(lat, lng, BALLARI_CENTER["lat"], BALLARI_CENTER["lng"])
    return dist <= BALLARI_RADIUS_KM

def calculate_eta(user_lat, user_lng):
    dist_km = haversine(ROBOT_DEPOT["lat"], ROBOT_DEPOT["lng"], user_lat, user_lng)
    time_hours = dist_km / ROBOT_SPEED_KMH
    time_minutes = time_hours * 60
    return round(time_minutes, 1), round(dist_km, 2)

def chatbot_response(message):
    msg = message.lower()
    import random

    if any(w in msg for w in ["plastic", "type", "pet", "hdpe", "pvc", "accept"]):
        key = "plastic_types"
    elif any(w in msg for w in ["revenue", "earn", "money", "credit", "value", "pay"]):
        key = "revenue"
    elif any(w in msg for w in ["work", "how", "function", "sensor", "detect", "crush"]):
        key = "working"
    elif any(w in msg for w in ["eta", "time", "arrive", "long", "minute"]):
        key = "eta"
    elif any(w in msg for w in ["power", "battery", "charge", "energy"]):
        key = "power"
    elif any(w in msg for w in ["ballari", "location", "city", "area", "service"]):
        key = "ballari"
    else:
        return f"I'm EcoBot 🤖 — your EcoRoboVahan assistant! Ask me about: plastic types, revenue, how it works, ETA calculation, power system, or service areas. What would you like to know?"

    responses = CHATBOT_KB[key]
    # Avoid repeating — track in session (simplified with random for now)
    return random.choice(responses)

# ── ROUTES ──

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/validate-location", methods=["POST"])
def validate_location():
    data = request.json
    lat = float(data.get("lat", 0))
    lng = float(data.get("lng", 0))

    dist_from_centre = haversine(lat, lng, BALLARI_CENTER["lat"], BALLARI_CENTER["lng"])

    if is_in_ballari(lat, lng):
        eta_mins, dist_km = calculate_eta(lat, lng)
        return jsonify({
            "valid": True,
            "eta_minutes": eta_mins,
            "distance_km": dist_km,
            "robot_position": ROBOT_DEPOT,
            "message": f"EcoRoboVahan arriving in {eta_mins} minutes 🚀"
        })
    else:
        return jsonify({
            "valid": False,
            "dist_from_centre": round(dist_from_centre, 1),
            "message": f"⚠️ Your location is {round(dist_from_centre,1)}km from Ballari city centre. Service covers 80km radius. Please check your coordinates — try using GPS auto-detect or enter Ballari area coordinates manually."
        })

@app.route("/api/submit-request", methods=["POST"])
def submit_request():
    data = request.json
    waste_type = data.get("waste_type", "").lower()

    if "plastic" not in waste_type and waste_type not in [k.lower() for k in PLASTIC_TYPES]:
        return jsonify({"success": False, "message": "❌ Only plastic waste accepted. Please select a plastic type."}), 400

    # Calculate revenue estimate
    qty_kg = float(data.get("quantity_kg", 1))
    plastic_key = data.get("plastic_subtype", "PET")
    value_per_kg = PLASTIC_TYPES.get(plastic_key, PLASTIC_TYPES["PET"])["value_per_kg"]
    estimated_revenue = round(qty_kg * value_per_kg * 0.4, 2)  # 40% to user

    req = {
        "id": len(requests_db) + 1,
        "name": data.get("name"),
        "phone": data.get("phone"),
        "lat": data.get("lat"),
        "lng": data.get("lng"),
        "address": data.get("address"),
        "waste_type": waste_type,
        "plastic_subtype": plastic_key,
        "quantity_kg": qty_kg,
        "estimated_revenue": estimated_revenue,
        "timestamp": datetime.now().isoformat(),
        "status": "robot_dispatched"
    }
    requests_db.append(req)

    eta_mins, dist_km = calculate_eta(float(data.get("lat", BALLARI_CENTER["lat"])),
                                       float(data.get("lng", BALLARI_CENTER["lng"])))

    return jsonify({
        "success": True,
        "request_id": req["id"],
        "eta_minutes": eta_mins,
        "distance_km": dist_km,
        "estimated_revenue": estimated_revenue,
        "robot_start": ROBOT_DEPOT,
        "message": f"Robot dispatched! Arriving in {eta_mins} minutes."
    })

@app.route("/api/robot-position", methods=["POST"])
def robot_position():
    """Returns interpolated robot position for animation."""
    data = request.json
    progress = float(data.get("progress", 0))  # 0.0 to 1.0
    dest_lat = float(data.get("dest_lat", BALLARI_CENTER["lat"]))
    dest_lng = float(data.get("dest_lng", BALLARI_CENTER["lng"]))

    cur_lat = ROBOT_DEPOT["lat"] + (dest_lat - ROBOT_DEPOT["lat"]) * progress
    cur_lng = ROBOT_DEPOT["lng"] + (dest_lng - ROBOT_DEPOT["lng"]) * progress

    return jsonify({"lat": cur_lat, "lng": cur_lng, "progress": progress})

@app.route("/api/chatbot", methods=["POST"])
def chatbot():
    data = request.json
    message = data.get("message", "")
    reply = chatbot_response(message)
    return jsonify({"reply": reply})

@app.route("/api/stats", methods=["GET"])
def stats():
    return jsonify({
        "plastic_collected_kg": 14820,
        "co2_saved_kg": 10682,
        "revenue_generated": 89340,
        "users_served": 4830,
        "robots_active": 7,
        "cities": 1,
        "weekly": [68, 85, 72, 91, 78, 95, 104]
    })

@app.route("/api/plastic-info", methods=["GET"])
def plastic_info():
    return jsonify(PLASTIC_TYPES)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
