/* ═══════════════════════════════════════
   EcoRoboVahan · app.js  v5
   Complete step-flow rewrite
═══════════════════════════════════════ */
'use strict';

/* ── constants ────────────────────────── */
const DEPOT   = { lat:15.1420, lng:76.9180 };
const BALLARI = { lat:15.1394, lng:76.9214 };
const SPEED   = 20;
const RADIUS  = 80;

/* ── state ────────────────────────────── */
const S = {
  step:1, name:'', phone:'', address:'',
  lat:null, lng:null, etaMins:null, distKm:null,
  plasticType:null, plasticRate:0, qty:1,
  mapObj:null, robotMarker:null, userMarker:null, routeLine:null,
  trackInterval:null
};

/* ── math helpers ─────────────────────── */
function hav(la1,lo1,la2,lo2){
  const R=6371,dr=Math.PI/180;
  const a=Math.sin((la2-la1)*dr/2)**2
    +Math.cos(la1*dr)*Math.cos(la2*dr)*Math.sin((lo2-lo1)*dr/2)**2;
  return R*2*Math.asin(Math.sqrt(a));
}
function calcETA(lat,lng){
  return Math.max(1, parseFloat((hav(DEPOT.lat,DEPOT.lng,lat,lng)/SPEED*60).toFixed(1)));
}

/* ── toast ────────────────────────────── */
function toast(msg, col='#00f5ff'){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.color = col;
  t.style.borderColor = col+'55';
  t.classList.add('show');
  clearTimeout(t._t);
  t._t = setTimeout(()=> t.classList.remove('show'), 3500);
}

/* ── animated counter ─────────────────── */
function countUp(el, target, dur=2000){
  let v=0;
  const step = target/(dur/16);
  const ti = setInterval(()=>{
    v = Math.min(v+step, target);
    el.textContent = Math.floor(v).toLocaleString('en-IN');
    if(v>=target) clearInterval(ti);
  }, 16);
}

/* ── smooth scroll ────────────────────── */
function scrollTo(id){
  const el = document.getElementById(id);
  if(el) el.scrollIntoView({ behavior:'smooth', block:'start' });
}

/* ══════════════════════════════════════
   STEP MACHINE  (core of the flow)
══════════════════════════════════════ */
function goStep(n){
  // 1. hide every step panel
  document.querySelectorAll('.req-step').forEach(el =>{
    el.style.display = 'none';
    el.classList.remove('active');
  });

  // 2. show the target step
  const panel = document.getElementById('step-'+n);
  if(!panel){ console.error('No panel for step', n); return; }
  panel.style.display = 'block';
  panel.classList.add('active');

  // 3. trigger slide-in animation on the card inside
  const card = panel.querySelector('.glass-card');
  if(card){
    card.style.animation = 'none';
    card.offsetHeight; // reflow
    card.style.animation = 'fadeInUp 0.4s ease';
  }

  S.step = n;

  // 4. update progress bar fill
  const fill = document.getElementById('rp-fill');
  if(fill) fill.style.width = ((n-1)/4*100)+'%';

  // 5. update step dots
  document.querySelectorAll('.rp-step').forEach(dot =>{
    const dn = parseInt(dot.dataset.step);
    dot.classList.remove('active','done');
    const num = dot.querySelector('.rp-dot');
    if(dn === n){
      dot.classList.add('active');
      num.textContent = dn;
    } else if(dn < n){
      dot.classList.add('done');
      num.textContent = '✓';
    } else {
      num.textContent = dn;
    }
  });

  // 6. per-step side-effects
  if(n===4) renderConfirmSummary();
  if(n===2 && S.lat) setTimeout(()=> initMap(S.lat, S.lng, S.etaMins, S.distKm), 200);

  // 7. scroll to section
  scrollTo('request-section');
}

/* ══════════════════════════════════════
   STEP 1 — LOCATION
══════════════════════════════════════ */
function step1_next(){
  const name  = document.getElementById('inp-name').value.trim();
  const phone = document.getElementById('inp-phone').value.trim();
  const addr  = document.getElementById('inp-address').value.trim();
  const lat   = parseFloat(document.getElementById('inp-lat').value);
  const lng   = parseFloat(document.getElementById('inp-lng').value);
  const err   = document.getElementById('loc-error');
  const hint  = document.getElementById('loc-demo-hint');

  err.style.display  = 'none';
  hint.style.display = 'none';

  // validation
  if(!name){  err.textContent='⚠️ Please enter your name.'; err.style.display='block'; return; }
  if(!phone){ err.textContent='⚠️ Please enter your phone number.'; err.style.display='block'; return; }
  if(!addr){  err.textContent='⚠️ Please enter your address or landmark.'; err.style.display='block'; return; }
  if(isNaN(lat)||isNaN(lng)){
    err.textContent='⚠️ Please enter coordinates or click "Auto-detect GPS".';
    err.style.display='block'; return;
  }

  // save to state
  S.name=name; S.phone=phone; S.address=addr;

  // show loading
  const btn = document.getElementById('step1-next');
  const orig = btn.textContent;
  btn.textContent = '⏳ Checking...';
  btn.disabled = true;

  fetch('/api/validate-location',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({lat, lng})
  })
  .then(r => r.json())
  .then(data =>{
    btn.textContent = orig; btn.disabled = false;
    if(data.valid){
      S.lat=lat; S.lng=lng;
      S.etaMins=data.eta_minutes; S.distKm=data.distance_km;
      toast('✅ Location verified — loading map!','#39ff14');
      goStep(2);
    } else {
      err.textContent = data.message;
      err.style.display = 'block';
      hint.style.display = 'block';
    }
  })
  .catch(()=>{
    btn.textContent = orig; btn.disabled = false;
    // offline fallback — do client-side check
    const dist = hav(lat,lng, BALLARI.lat, BALLARI.lng);
    if(dist > RADIUS){
      err.textContent = `⚠️ Your location is ${dist.toFixed(1)} km from Ballari city. Service covers ${RADIUS} km radius. Use the quick-set buttons below.`;
      err.style.display  = 'block';
      hint.style.display = 'block';
      return;
    }
    S.lat=lat; S.lng=lng;
    S.distKm  = parseFloat(hav(lat,lng,DEPOT.lat,DEPOT.lng).toFixed(2));
    S.etaMins = calcETA(lat,lng);
    toast('✅ Location OK — loading map!','#39ff14');
    goStep(2);
  });
}

/* ── GPS detect ───────────────────────── */
function doGPS(){
  toast('📍 Detecting GPS...');
  const ok = pos =>{
    const la=pos.coords.latitude, lo=pos.coords.longitude;
    if(hav(la,lo,BALLARI.lat,BALLARI.lng) <= RADIUS){
      document.getElementById('inp-lat').value = la.toFixed(6);
      document.getElementById('inp-lng').value = lo.toFixed(6);
      toast('✅ GPS detected!','#39ff14');
    } else {
      setDemoLoc();
    }
  };
  const fail = ()=> setDemoLoc();
  navigator.geolocation ? navigator.geolocation.getCurrentPosition(ok,fail) : setDemoLoc();
}

function setDemoLoc(place='bitm'){
  const locs = {
    bitm:   { lat:'15.1677', lng:'76.9125', addr:'BITM College, Ballari' },
    centre: { lat:'15.1394', lng:'76.9214', addr:'Gandhi Circle, Ballari' },
    hospet: { lat:'15.2689', lng:'76.3870', addr:'Hospet, Ballari Dist.' }
  };
  const l = locs[place] || locs.bitm;
  document.getElementById('inp-lat').value   = l.lat;
  document.getElementById('inp-lng').value   = l.lng;
  document.getElementById('inp-address').value = l.addr;
  toast('📍 Location set: '+l.addr,'#39ff14');
}

/* ══════════════════════════════════════
   STEP 2 — MAP & ETA
══════════════════════════════════════ */
function initMap(userLat, userLng, etaMins, distKm){
  const loader = document.getElementById('map-loader');

  // if map already exists just update markers
  if(S.mapObj){
    if(loader) loader.style.display='none';
    if(S.userMarker)  S.userMarker.setLatLng([userLat,userLng]);
    if(S.routeLine)   S.routeLine.setLatLngs([[DEPOT.lat,DEPOT.lng],[userLat,userLng]]);
    S.mapObj.fitBounds([[DEPOT.lat,DEPOT.lng],[userLat,userLng]],{padding:[50,50]});
    renderETA(etaMins, distKm);
    return;
  }

  // create new map
  const map = L.map('map-container', { zoomControl:true });
  S.mapObj = map;

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
    attribution:'© OpenStreetMap', maxZoom:18
  }).addTo(map);

  // service zone ring
  L.circle([BALLARI.lat,BALLARI.lng],{
    radius:80000, color:'#00f5ff', fillColor:'#00f5ff',
    fillOpacity:.03, weight:1, dashArray:'6,5'
  }).addTo(map);

  // icons
  const rIcon = L.divIcon({
    html:'<div style="font-size:28px;filter:drop-shadow(0 0 8px #39ff14)">🤖</div>',
    iconSize:[32,32], iconAnchor:[16,16], className:''
  });
  const uIcon = L.divIcon({
    html:'<div style="width:16px;height:16px;background:#39ff14;border-radius:50%;box-shadow:0 0 16px #39ff14;border:2px solid #fff"></div>',
    iconSize:[16,16], iconAnchor:[8,8], className:''
  });

  S.robotMarker = L.marker([DEPOT.lat,DEPOT.lng],{icon:rIcon}).addTo(map)
    .bindPopup('<b style="color:#00f5ff">🤖 EcoRoboVahan Depot</b>');

  S.userMarker = L.marker([userLat,userLng],{icon:uIcon}).addTo(map)
    .bindPopup('<b style="color:#39ff14">📍 Your Location</b>');

  S.routeLine = L.polyline([[DEPOT.lat,DEPOT.lng],[userLat,userLng]],{
    color:'#39ff14', weight:3, opacity:.7, dashArray:'8,5'
  }).addTo(map);

  map.fitBounds([[DEPOT.lat,DEPOT.lng],[userLat,userLng]],{padding:[50,50]});

  // hide loader after tiles load
  map.whenReady(()=>{
    setTimeout(()=>{
      if(loader) loader.style.display='none';
      map.invalidateSize();
    }, 400);
  });

  renderETA(etaMins, distKm);
}

function renderETA(mins, dist){
  const chip = document.getElementById('eta-chip');
  const di   = document.getElementById('dist-info');
  if(chip) chip.innerHTML = `🚀 Arriving in ~${mins} min`;
  if(di)   di.textContent = `${dist} km from depot · Speed: ${SPEED} km/h`;
}

/* ══════════════════════════════════════
   STEP 3 — WASTE TYPE
══════════════════════════════════════ */
function selectPlastic(type, rate, cardEl){
  document.querySelectorAll('.ptype').forEach(c=> c.classList.remove('selected'));
  cardEl.classList.add('selected');
  S.plasticType = type;
  S.plasticRate = rate;

  // show success feedback
  const fb = document.getElementById('plastic-feedback');
  fb.className = 'msg-success';
  fb.textContent = `✅ ${type} plastic accepted! EcoRoboVahan will process this material.`;
  fb.style.display = 'block';

  // show qty section
  document.getElementById('qty-wrap').style.display = 'block';
  updateRevPreview();

  // enable next button
  const nxt = document.getElementById('step3-next');
  nxt.disabled = false;
  nxt.style.opacity = '1';
}

function updateRevPreview(){
  const qty  = parseFloat(document.getElementById('inp-qty').value)||1;
  S.qty = qty;
  const earn = (qty * S.plasticRate * 0.4).toFixed(2);
  const el   = document.getElementById('rev-preview');
  if(el) el.textContent = `💰 You'll earn ~₹${earn} EcoCredits for ${qty}kg of ${S.plasticType}`;
}

/* ══════════════════════════════════════
   STEP 4 — CONFIRM SUMMARY
══════════════════════════════════════ */
function renderConfirmSummary(){
  const earn = (S.qty * S.plasticRate * 0.4).toFixed(2);
  const rows = [
    ['Name',         S.name],
    ['Phone',        S.phone],
    ['Location',     S.address],
    ['Coordinates',  `${S.lat?.toFixed(4)}, ${S.lng?.toFixed(4)}`],
    ['Plastic Type', S.plasticType],
    ['Quantity',     S.qty+' kg'],
    ['Market Rate',  '₹'+S.plasticRate+'/kg'],
    ['ETA',          '~'+S.etaMins+' minutes', true],
    ['Distance',     S.distKm+' km'],
    ['Your Earnings','₹'+earn+' EcoCredits', true],
  ];
  document.getElementById('confirm-summary').innerHTML = rows.map(([k,v,hl])=>`
    <div class="cs-row">
      <span class="cs-k">${k}</span>
      <span class="cs-v ${hl?'hl':''}">${v}</span>
    </div>`).join('');
}

/* ══════════════════════════════════════
   STEP 5 — DISPATCH & LIVE TRACKING
══════════════════════════════════════ */
function dispatchRobot(){
  const btn   = document.getElementById('dispatch-btn');
  const label = document.getElementById('dispatch-label');
  const spin  = document.getElementById('dispatch-spin');

  label.style.display = 'none';
  spin.style.display  = 'inline-block';
  btn.disabled = true;

  const earn = (S.qty * S.plasticRate * 0.4).toFixed(2);

  const payload = {
    name:S.name, phone:S.phone, address:S.address,
    lat:S.lat, lng:S.lng,
    waste_type:'plastic', plastic_subtype:S.plasticType,
    quantity_kg:S.qty
  };

  const proceed = (etaMins, distKm, revenue) =>{
    label.style.display = '';
    spin.style.display  = 'none';
    btn.disabled = false;
    toast('🤖 Robot dispatched!', '#39ff14');
    goStep(5);
    startTracking(etaMins, distKm, revenue);
  };

  fetch('/api/submit-request',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  })
  .then(r=> r.json())
  .then(data=>{
    if(data.success){
      proceed(data.eta_minutes||S.etaMins, data.distance_km||S.distKm, data.estimated_revenue||earn);
    } else {
      label.style.display=''; spin.style.display='none'; btn.disabled=false;
      toast(data.message,'#ff4466');
    }
  })
  .catch(()=> proceed(S.etaMins, S.distKm, earn));
}

/* ── live tracking animation ──────────── */
function startTracking(etaMins, distKm, revenue){
  let elapsed  = 0;
  let progress = 0;
  const totalSec = etaMins * 60;
  // simulate arrival in ~60 real seconds regardless of ETA
  const tickSec  = totalSec / 30;

  const milestones = [
    { at:0,    txt:'🤖 Robot dispatched from depot' },
    { at:0.15, txt:'📡 GPS navigation locked to your location' },
    { at:0.40, txt:'🛣️ Robot en route — making good progress' },
    { at:0.70, txt:'📍 Almost there — 2 minutes away!' },
    { at:1.0,  txt:'✅ EcoRoboVahan has arrived!' },
  ];

  function render(){
    const remSec = Math.max(0, totalSec - elapsed);
    const remMin = remSec / 60;
    const kmLeft = (distKm * (1-progress)).toFixed(2);

    const etaStr = progress>=1
      ? '✅ ARRIVED!'
      : remMin < 1
        ? `~${Math.ceil(remSec)}s`
        : `~${Math.ceil(remMin)} min`;

    document.getElementById('live-eta').innerHTML=`
      <div class="lte-big">${etaStr}</div>
      <div class="lte-dist">
        ${distKm} km total &nbsp;·&nbsp; ${kmLeft} km remaining &nbsp;·&nbsp; ${SPEED} km/h
      </div>
      <div class="lte-pct-row">
        <span>🏭 Depot</span>
        <span>${Math.round(progress*100)}% complete</span>
        <span>📍 You</span>
      </div>
      <div class="lte-bar-bg">
        <div class="lte-bar" style="width:${progress*100}%"></div>
      </div>`;

    // milestone list
    document.getElementById('milestones').innerHTML = milestones.map(m=>`
      <div class="ms-item ${progress>=m.at?'done':''}">
        <div class="ms-dot"></div>
        <span>${m.txt}</span>
      </div>`).join('');

    // arrival card
    if(progress >= 1){
      const done = document.getElementById('arrival-done');
      done.style.display = 'block';
      done.innerHTML=`
        <div style="font-size:2.5rem">🎉</div>
        <strong style="font-size:1.1rem">EcoRoboVahan has arrived!</strong><br><br>
        Drop your <strong>${S.plasticType}</strong> plastic into the <strong>♻ INSERT</strong> slot.<br><br>
        <strong style="color:#39ff14;font-size:1.2em">Your earnings: ₹${revenue} EcoCredits</strong><br>
        <small style="opacity:.6">CO₂ prevented: ~${(S.qty*2.1).toFixed(1)} kg</small>`;
    }

    // move robot on map
    if(S.robotMarker){
      S.robotMarker.setLatLng([
        DEPOT.lat + (S.lat - DEPOT.lat) * progress,
        DEPOT.lng + (S.lng - DEPOT.lng) * progress
      ]);
    }
  }

  render();

  S.trackInterval = setInterval(()=>{
    elapsed  += tickSec;
    progress  = Math.min(elapsed / totalSec, 1);
    render();
    if(progress >= 1){
      clearInterval(S.trackInterval);
      toast('🤖 EcoRoboVahan arrived at your location!', '#39ff14');
    }
  }, 2000);
}

/* ══════════════════════════════════════
   INTRO SEQUENCE
══════════════════════════════════════ */
let introTO;

function runIntro(){
  const seq=[
    {t:2200, lb:'⚡ SYSTEM ONLINE',      fn:()=>setRoverTxt('READY...')},
    {t:3200, lb:'📦 PLASTIC DETECTED',   fn:()=>{
      const b=document.getElementById('bottle-group');
      b.style.animation='bottleFall .9s cubic-bezier(.34,1.56,.64,1) forwards';
      b.style.opacity='1'; setRoverTxt('ITEM INCOMING...');
    }},
    {t:4600, lb:'🔬 SCANNING MATERIAL',  fn:()=>{
      const sb=document.getElementById('scan-beam');
      sb.style.opacity='1';
      sb.style.animation='scanPulse 1.2s ease-in-out infinite';
      setRoverTxt('NIR SCAN...');
    }},
    {t:6000, lb:'✅ PLASTIC ACCEPTED',   fn:()=>{
      document.getElementById('scan-beam').style.opacity='0';
      const ab=document.getElementById('accept-badge');
      ab.style.opacity='1';
      ab.style.animation='acceptPop .6s cubic-bezier(.34,1.56,.64,1) forwards';
      document.getElementById('bottle-group').style.opacity='0';
      setRoverTxt('✓ ACCEPTED');
    }},
    {t:7200, lb:'⚙️ CRUSHING TO POWDER', fn:()=>{
      document.getElementById('accept-badge').style.opacity='0';
      const ce=document.getElementById('crush-effect');
      ce.style.opacity='1';
      ce.style.animation='crushBurst .8s ease forwards';
      setRoverTxt('CRUSHING...');
    }},
    {t:8400, lb:'✅ STORED IN TROLLEY',  fn:()=>{
      document.getElementById('crush-effect').style.opacity='0';
      document.getElementById('trolley-powder').style.opacity='1';
      setRoverTxt('✓ STORED');
      setLabel('🏆 COMPLETE · LAUNCHING WEBSITE...');
    }},
  ];

  seq.forEach(s=> setTimeout(()=>{
    if(!document.getElementById('intro-overlay').classList.contains('hidden')){
      setLabel(s.lb); s.fn&&s.fn();
    }
  }, s.t));

  introTO = setTimeout(endIntro, 10200);
}

function setRoverTxt(t){
  const e=document.getElementById('rover-status-text'); if(e) e.textContent=t;
}
function setLabel(t){
  const l=document.getElementById('intro-step-label');
  l.style.opacity='0';
  setTimeout(()=>{ l.textContent=t; l.style.opacity='1'; }, 180);
}

function endIntro(){
  clearTimeout(introTO);
  const ov=document.getElementById('intro-overlay');
  ov.classList.add('intro-exit');
  setTimeout(()=>{
    ov.classList.add('hidden');
    ov.classList.remove('intro-exit');

    document.getElementById('main-content').classList.add('visible');
    document.getElementById('navbar').classList.add('visible');
    document.getElementById('chat-btn').classList.add('visible');

    startHeroCounters();
    buildBarChart();
    buildRatesTable();
    runCalc();
    setTimeout(()=> toast('🤖 EcoRoboVahan is online · Ballari'), 1000);
    setTimeout(animDashBars, 800);
  }, 900);
}

/* ══════════════════════════════════════
   STARS CANVAS
══════════════════════════════════════ */
const cvs=document.getElementById('stars-canvas');
const c2d=cvs.getContext('2d');
let stars=[];
function rsz(){ cvs.width=innerWidth; cvs.height=innerHeight; }
rsz(); window.addEventListener('resize',rsz);
stars=Array.from({length:200},()=>({
  x:Math.random()*cvs.width, y:Math.random()*cvs.height,
  r:Math.random()*1.5+.2, a:Math.random()*.6+.1,
  s:Math.random()*.25+.04, t:Math.random()*Math.PI*2
}));
(function drawStars(){
  c2d.clearRect(0,0,cvs.width,cvs.height);
  stars.forEach(s=>{
    s.t+=.018; s.y+=s.s;
    if(s.y>cvs.height){ s.y=0; s.x=Math.random()*cvs.width; }
    c2d.beginPath();
    c2d.arc(s.x,s.y,s.r,0,Math.PI*2);
    c2d.fillStyle=`rgba(0,245,255,${s.a*(.55+.45*Math.sin(s.t))})`;
    c2d.fill();
  });
  requestAnimationFrame(drawStars);
})();

/* ══════════════════════════════════════
   CURSOR
══════════════════════════════════════ */
const cdot=document.getElementById('cursor-dot');
const cring=document.getElementById('cursor-ring');
let mx=0,my=0,rx=0,ry=0;
document.addEventListener('mousemove',e=>{
  mx=e.clientX; my=e.clientY;
  cdot.style.left=mx+'px'; cdot.style.top=my+'px';
});
(function animRing(){
  rx+=(mx-rx)*.11; ry+=(my-ry)*.11;
  cring.style.left=rx+'px'; cring.style.top=ry+'px';
  requestAnimationFrame(animRing);
})();

/* ══════════════════════════════════════
   SCROLL REVEAL
══════════════════════════════════════ */
function initReveal(){
  const obs=new IntersectionObserver(en=>{
    en.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('in-view'); });
  },{threshold:.1});
  document.querySelectorAll('.reveal').forEach(el=> obs.observe(el));
}

/* ══════════════════════════════════════
   HERO COUNTERS
══════════════════════════════════════ */
function startHeroCounters(){
  document.querySelectorAll('[data-target]').forEach(el=>
    countUp(el, parseInt(el.dataset.target), 2000)
  );
}

/* ══════════════════════════════════════
   BAR CHART
══════════════════════════════════════ */
function buildBarChart(){
  const data=[{l:'Mon',v:68},{l:'Tue',v:85},{l:'Wed',v:72},{l:'Thu',v:91},{l:'Fri',v:78},{l:'Sat',v:104},{l:'Sun',v:62}];
  const max=Math.max(...data.map(d=>d.v));
  const el=document.getElementById('bar-chart');
  if(!el) return;
  el.innerHTML=data.map(d=>`
    <div class="bci">
      <div class="bc-val">${d.v}kg</div>
      <div class="bc-bar" data-h="${(d.v/max)*100}"></div>
      <div class="bc-lbl">${d.l}</div>
    </div>`).join('');
  setTimeout(()=> el.querySelectorAll('.bc-bar').forEach(b=> b.style.height=b.dataset.h+'%'), 500);
}

function animDashBars(){
  document.querySelectorAll('.dash-num[data-target]').forEach(el=>
    countUp(el, parseInt(el.dataset.target), 2200)
  );
}

/* ══════════════════════════════════════
   RATES TABLE & REVENUE CALC
══════════════════════════════════════ */
function buildRatesTable(){
  const r={PET:{r:12,u:'Bottles'},HDPE:{r:15,u:'Jugs'},PP:{r:11,u:'Caps'},LDPE:{r:10,u:'Bags'},PVC:{r:8,u:'Pipes'},PS:{r:6,u:'Foam'}};
  const el=document.getElementById('rates-table');
  if(!el) return;
  el.innerHTML=Object.entries(r).map(([k,v])=>`
    <div class="pr-row">
      <span style="color:var(--text)">${k} – ${v.u}</span>
      <span style="font-family:'JetBrains Mono',monospace;color:var(--green)">₹${v.r}/kg</span>
    </div>`).join('');
}

function runCalc(){
  const qty  = parseFloat(document.getElementById('calc-qty')?.value)||5;
  const raw  = document.getElementById('calc-type')?.value||'PET,12';
  const rate = parseFloat(raw.split(',')[1])||12;
  const el   = document.getElementById('calc-result');
  if(!el) return;
  el.innerHTML=`
    <div>Market value: <strong>₹${(qty*rate).toFixed(2)}</strong></div>
    <div>Your EcoCredits (40%): <strong style="color:#39ff14;font-size:1.05em">₹${(qty*rate*.4).toFixed(2)}</strong></div>
    <div style="font-size:.75rem;opacity:.6;margin-top:4px">CO₂ saved: ~${(qty*2.1).toFixed(1)} kg</div>`;
}

/* ══════════════════════════════════════
   CHATBOT
══════════════════════════════════════ */
const KB={
  plastic:["EcoRoboVahan accepts PET (₹12/kg), HDPE (₹15/kg), PP (₹11/kg), LDPE (₹10/kg), PVC (₹8/kg), PS (₹6/kg). NIR sensors classify in 2 seconds. 🔬","PET water bottles are most common. HDPE jugs fetch highest value at ₹15/kg. Non-plastic items are auto-ejected.","6 resin types accepted. All crushed to <2mm powder. Paper, glass, metal, organic — all rejected. ♻️"],
  revenue:["You earn 40% of powder sale value as EcoCredits. HDPE: ₹6/kg to you. PET: ₹4.80/kg. 💰","10kg plastic/month → ₹40–60 EcoCredits. Redeem at 50+ Ballari partner stores.","Crushed powder sold to industrial recyclers. 40% shared with you instantly."],
  working:["EcoRoboVahan uses SLAM + LIDAR + GPS. Builds real-time map of its route, avoiding obstacles autonomously.","Inside: NIR sensor → 2s scan → plastic enters 500W shredder → <2mm powder → sealed 20kg trolley compartment.","4G LTE location updates every 2s. Battery <15% → auto-return to depot. Fleet rotation = 24/7 service. ⚡"],
  eta:["ETA = GPS distance ÷ 20 km/h. Updates every 2 seconds. No fake timers — pure physics! 📡","For 2km: ~6 min. For 5km: ~15 min. Robots run at 18–22 km/h on Ballari roads.","Haversine formula calculates distance. Progress bar shows real interpolated robot position."],
  power:["72V 50Ah rechargeable lithium power bank. 80km per charge. Fast-charge 0→80% in 45 min. 🔋","Fleet rotation: one charges, another covers. ₹2 per charge cycle. Zero downtime.","500W shredder in 2–5 second bursts. One charge processes ~200 items."],
  ballari:["Live in Ballari + Vijayanagara district — Ballari city, Hospet, Sandur, 80km radius. 🏭","7 active robots. Expanding to Raichur, Koppal by Q3 2026."],
  hello:["Hey! I'm EcoBot 🤖 Ask me about plastic types, earnings, how the robot works, ETA, or Ballari coverage!","Namaskara! 👋 Ready to recycle? Ask me anything about EcoRoboVahan! ♻️"]
};
const KBi={};

function initChatbot(){
  setTimeout(()=>
    addMsg("👋 Namaskara! I'm EcoBot. Ask me about plastic types, earnings, robot navigation, ETA, or Ballari service area! 🤖",'bot'),
  1400);
}

function openChat(open){
  document.getElementById('chat-panel').classList.toggle('open',open);
}

function addMsg(txt,who){
  const el=document.getElementById('chat-msgs');
  const d=document.createElement('div');
  d.className=`cmsg ${who}`; d.textContent=txt;
  el.appendChild(d); el.scrollTop=el.scrollHeight;
}

function sendChat(){
  const inp=document.getElementById('chat-inp');
  const msg=inp.value.trim(); if(!msg) return;
  addMsg(msg,'user'); inp.value='';
  const ty=document.createElement('div');
  ty.className='cmsg bot'; ty.id='ty-ind';
  ty.innerHTML='<em style="opacity:.4">typing…</em>';
  document.getElementById('chat-msgs').appendChild(ty);
  document.getElementById('chat-msgs').scrollTop=9999;
  setTimeout(()=>{
    document.getElementById('ty-ind')?.remove();
    addMsg(botReply(msg.toLowerCase()),'bot');
  }, 600+Math.random()*400);
}

function botReply(m){
  let k='hello';
  if(m.match(/plastic|pet|hdpe|pvc|ldpe|pp|ps|accept|type|material/)) k='plastic';
  else if(m.match(/revenue|earn|money|credit|pay|value|profit/)) k='revenue';
  else if(m.match(/work|how|function|sensor|detect|crush|navigate|slam/)) k='working';
  else if(m.match(/eta|time|arrive|long|minute|fast|speed|when/)) k='eta';
  else if(m.match(/power|battery|charge|energy/)) k='power';
  else if(m.match(/ballari|hospet|location|city|area|service|where/)) k='ballari';
  else if(m.match(/hi|hello|hey|namaste/)) k='hello';
  else return "Ask me about: plastic types, earnings, how it works, ETA, power, or Ballari area. 🤖";
  const arr=KB[k];
  KBi[k]=((KBi[k]||0)+1)%arr.length;
  return arr[KBi[k]];
}

/* ══════════════════════════════════════
   DOM READY — wire ALL events here
══════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', ()=>{

  runIntro();
  initReveal();
  initChatbot();

  // ── Initialise step 1 as visible ──
  // Make sure only step-1 is shown at start
  document.querySelectorAll('.req-step').forEach(el=>{
    el.style.display = 'none';
    el.classList.remove('active');
  });
  const s1 = document.getElementById('step-1');
  if(s1){ s1.style.display='block'; s1.classList.add('active'); }

  // ── Intro ──
  document.getElementById('skip-btn').addEventListener('click', endIntro);

  // ── Nav links ──
  document.querySelectorAll('[data-scroll]').forEach(a=>{
    a.addEventListener('click', e=>{ e.preventDefault(); scrollTo(a.dataset.scroll); });
  });

  // ── Nav CTA ──
  document.getElementById('nav-cta-btn').addEventListener('click', ()=>{
    scrollTo('request-section'); goStep(1);
  });

  // ── Hero buttons ──
  document.getElementById('hero-call-btn').addEventListener('click', ()=>{
    scrollTo('request-section'); goStep(1);
  });
  document.getElementById('hero-hiw-btn').addEventListener('click', ()=>{
    scrollTo('how-it-works');
  });

  // ── How it Works CTA ──
  document.getElementById('hiw-cta-btn').addEventListener('click', ()=>{
    scrollTo('request-section'); goStep(1);
  });

  // ── Step 1 ──
  document.getElementById('gps-btn').addEventListener('click', doGPS);
  document.getElementById('step1-next').addEventListener('click', step1_next);

  // ── Step 2 ──
  document.getElementById('step2-next').addEventListener('click', ()=> goStep(3));

  // ── Step 3 ── plastic cards (delegated)
  document.getElementById('plastic-grid').addEventListener('click', e=>{
    const card = e.target.closest('.ptype');
    if(!card) return;
    selectPlastic(card.dataset.type, parseInt(card.dataset.rate), card);
  });
  document.getElementById('inp-qty').addEventListener('input', updateRevPreview);
  document.getElementById('step3-next').addEventListener('click', ()=>{
    if(!S.plasticType){
      const fb=document.getElementById('plastic-feedback');
      fb.className='msg-error';
      fb.textContent='❌ Please select a plastic type first.';
      fb.style.display='block';
      return;
    }
    goStep(4);
  });

  // ── Step 4 ──
  document.getElementById('dispatch-btn').addEventListener('click', dispatchRobot);

  // ── Back buttons (delegated) ──
  document.addEventListener('click', e=>{
    const b = e.target.closest('.back-btn');
    if(b) goStep(parseInt(b.dataset.to));
  });

  // ── Demo location buttons ──
  document.querySelectorAll('[data-demo]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      setDemoLoc(btn.dataset.demo);
      document.getElementById('loc-error').style.display='none';
      document.getElementById('loc-demo-hint').style.display='none';
    });
  });

  // ── Revenue calc ──
  document.getElementById('calc-qty').addEventListener('input', runCalc);
  document.getElementById('calc-type').addEventListener('change', runCalc);

  // ── Chatbot ──
  document.getElementById('chat-btn').addEventListener('click', ()=> openChat(true));
  document.getElementById('chat-close').addEventListener('click', ()=> openChat(false));
  document.getElementById('chat-send').addEventListener('click', sendChat);
  document.getElementById('chat-inp').addEventListener('keydown', e=>{
    if(e.key==='Enter') sendChat();
  });

});
